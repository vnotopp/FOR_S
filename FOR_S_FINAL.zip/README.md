# FOR S — FINAL (Sakura Pink + Dark Lavender)

This is the final FOR S project customized as requested:
- Light = sakura pink theme
- Dark = lavender deep theme
- Removed Sounds section
- Restored Flashcards & Scheduler
- Pomodoro dark-mode fixes
- Personalized message: Made for babyy kamat

## Run
1. npm install
2. npm run dev
3. Open http://localhost:5173
